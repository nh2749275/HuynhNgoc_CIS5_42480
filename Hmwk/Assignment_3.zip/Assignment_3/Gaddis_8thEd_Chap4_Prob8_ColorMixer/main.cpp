/* 
 * File:   main.cpp
 * Author: Ngoc Huynh
 * Created on March 20th, 2018, 11:19 PM
 * Purpose:  This program gives you a color by mixing 2 primary colors
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
#include <string>
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    string red, yellow, blue, color1, color2;
    
    //Initial Variables
    
    //Map/Process Inputs to Outputs
    
    //Display Outputs
    cout << "Enter 2 colors you want to mix" << endl;
    cin >> color1 >> color2;
    
    color1 = red;
    color2 = yellow;
    cout << "Enter 2 colors to mix " << endl;
    cin >> color1 >> color2;
    
    if (color1 = red & color2 = yellow)
        cout << color1 << " mixed with" << color2 << makes <<" orange" << endl;
    
    //Exit program!
    return 0;
}